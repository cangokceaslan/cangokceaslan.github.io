---
title: Carousel
menu: docs.carousel
---

The Carousel is a slideshow for cycling through elements.

{% example html columns=1 %}
{% include ui/carousel.html show-indicators=true show-controls=true id="carousel-sample" %}
{% endexample %}
