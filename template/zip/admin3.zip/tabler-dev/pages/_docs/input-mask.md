---
title: Input mask
---

{% example %}
<label class="form-label">Telephone mask</label>
{% include ui/input-mask.html mask="(00) 0000-0000" placeholder="(00) 0000-0000" visible=true %}
{% endexample %}
