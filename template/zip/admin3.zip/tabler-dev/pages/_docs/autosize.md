---
title: Autosize
done: true
---

A small, stand-alone script to automatically adjust textarea height.

### Default markup

{% example html %}
<label class="form-label">Autosize example</label>
<textarea class="form-control" data-toggle="autosize" placeholder="Typing something&hellip;"></textarea>
{% endexample %}
