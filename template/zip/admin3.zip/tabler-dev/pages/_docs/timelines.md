---
title: Timelines
menu: docs.timelines
---

### Timeline
{% example html columns=3 %}
	{% include cards/timeline.html %}
{% endexample %}

### Simple Timeline
{% example html columns=1 %}
	{% include cards/timeline.html simple=true %}
{% endexample %}
